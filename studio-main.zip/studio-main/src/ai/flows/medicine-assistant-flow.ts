'use server';
/**
 * @fileOverview A medicine assistant AI flow.
 *
 * - medicineAssistant - A function that answers questions about a medicine.
 * - MedicineAssistantInput - The input type for the medicineAssistant function.
 * - MedicineAssistantOutput - The return type for the medicineAssistant function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import type { Medicine } from '@/lib/types';

const MedicineSchema = z.object({
  name: z.string(),
  usage: z.string(),
  dosage: z.string(),
  benefits: z.array(z.string()),
  sideEffects: z.array(z.string()),
  warnings: z.array(z.string()),
  timetable: z.object({
    morning: z.boolean(),
    afternoon: z.boolean(),
    night: z.boolean(),
  }),
  isEssential: z.boolean(),
  ageWarnings: z.object({
    child: z.array(z.string()),
    adult: z.array(z.string()),
    elderly: z.array(z.string()),
  }),
  interactionWarnings: z.array(z.string()),
});

const MedicineAssistantInputSchema = z.object({
  medicine: MedicineSchema,
  question: z.string().describe("The user's question about the medicine."),
});
export type MedicineAssistantInput = z.infer<typeof MedicineAssistantInputSchema>;

const MedicineAssistantOutputSchema = z.object({
  response: z.string().describe("The AI assistant's answer."),
});
export type MedicineAssistantOutput = z.infer<typeof MedicineAssistantOutputSchema>;


export async function medicineAssistant(input: MedicineAssistantInput): Promise<MedicineAssistantOutput> {
    const flowInput = {
        ...input,
        medicine: {
            ...input.medicine,
            // Convert boolean timetable to string for better prompting
            timetable: `Morning: ${input.medicine.timetable.morning ? 'Yes' : 'No'}, Afternoon: ${input.medicine.timetable.afternoon ? 'Yes' : 'No'}, Night: ${input.medicine.timetable.night ? 'Yes' : 'No'}`
        }
    };
    return medicineAssistantFlow(flowInput as any);
}

const prompt = ai.definePrompt({
    name: 'medicineAssistantPrompt',
    input: { schema: MedicineAssistantInputSchema },
    prompt: `You are a friendly and helpful AI Medicine Assistant named 'PharmaBot'. Your goal is to explain information about medicines in a simple, calm, and non-alarming way for a common user.

**IMPORTANT RULES:**
1.  **DO NOT DIAGNOSE DISEASES.** If the user asks about symptoms or conditions, gently refuse and tell them to consult a healthcare professional.
2.  **DO NOT PRESCRIBE OR RECOMMEND NEW MEDICINES.** Your knowledge is limited to the single medicine provided in the context.
3.  **STICK TO THE PROVIDED INFORMATION.** Only use the data given below about the medicine. Do not invent or infer information. If the information is not available in the context, state that you don't have that specific information and recommend consulting a professional.
4.  **ALWAYS BE SIMPLE AND CLEAR.** Avoid scary medical jargon.
5.  **ALWAYS INCLUDE THIS DISCLAIMER** at the end of your response, on a new line: "---
*This information is for educational purposes only. Always consult a healthcare professional for medical advice.*"

Here is the information for the medicine **{{medicine.name}}**:
- **Common Use:** {{medicine.usage}}
- **Dosage Instructions:** {{medicine.dosage}}
- **Dosage Timeline:** {{medicine.timetable}}
- **Benefits:**
{{#each medicine.benefits}}
- {{this}}
{{/each}}
- **Possible Side Effects:**
{{#each medicine.sideEffects}}
- {{this}}
{{/each}}
- **General Warnings:**
{{#each medicine.warnings}}
- {{this}}
{{/each}}
- **Age-Specific Warnings:**
  - Child: 
{{#each medicine.ageWarnings.child}}
- {{this}}
{{/each}}
  - Adult: 
{{#each medicine.ageWarnings.adult}}
- {{this}}
{{/each}}
  - Elderly: 
{{#each medicine.ageWarnings.elderly}}
- {{this}}
{{/each}}
- **Interaction Warnings (Do NOT take with):**
{{#each medicine.interactionWarnings}}
- {{this}}
{{/each}}

---

Now, please answer the following user question based **ONLY** on the information above.

**User Question:** "{{question}}"
`,
});

const medicineAssistantFlow = ai.defineFlow(
    {
        name: 'medicineAssistantFlow',
        inputSchema: MedicineAssistantInputSchema,
        outputSchema: MedicineAssistantOutputSchema,
    },
    async (input) => {
        const response = await prompt(input);
        return { response: response.text };
    }
);
