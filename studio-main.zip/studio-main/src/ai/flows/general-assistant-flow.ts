'use server';

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GeneralAssistantInputSchema = z.object({
  question: z.string().describe("The user's question to the assistant."),
});
export type GeneralAssistantInput = z.infer<typeof GeneralAssistantInputSchema>;

const GeneralAssistantOutputSchema = z.object({
  response: z.string().describe("The AI assistant's answer."),
});
export type GeneralAssistantOutput = z.infer<typeof GeneralAssistantOutputSchema>;

export async function generalAssistant(input: GeneralAssistantInput): Promise<GeneralAssistantOutput> {
  return generalAssistantFlow(input);
}

const prompt = ai.definePrompt({
    name: 'generalAssistantPrompt',
    input: { schema: GeneralAssistantInputSchema },
    prompt: `You are a friendly and helpful AI Assistant for an app called 'MedMap'. Your goal is to help users navigate the app and find information about medicines and pharmacies.

**MedMap's Features:**
- Users can search for pharmacies by name, city, or medicine.
- Users can view details about medicines, including dosage, side effects, and warnings.
- Users can bookmark medicines for quick access.
- There is an 'Emergency Mode' that filters for 24/7 pharmacies with essential medicines.
- Users can add items to a shopping cart and checkout.
- There is an AI Medicine Assistant (PharmaBot) for specific questions about a particular medicine.

**IMPORTANT RULES:**
1.  **DO NOT DIAGNOSE DISEASES OR GIVE MEDICAL ADVICE.** If the user asks about symptoms, conditions, or for medical advice, gently refuse and tell them to consult a healthcare professional.
2.  **DO NOT PRESCRIBE OR RECOMMEND SPECIFIC MEDICINES.** You can tell them how to search for a medicine, but not which one to take.
3.  **STICK TO THE APP's FUNCTIONALITY.** Your primary role is to help users with the MedMap app itself.
4.  **BE FRIENDLY AND CONCISE.** Keep your answers clear and to the point.
5.  **ALWAYS INCLUDE THIS DISCLAIMER** if the conversation touches on health or medicines, on a new line: "---
*I am an AI assistant for the MedMap app and cannot provide medical advice. Always consult a healthcare professional for medical concerns.*"

**User Question:** "{{question}}"
`,
});

const generalAssistantFlow = ai.defineFlow(
    {
        name: 'generalAssistantFlow',
        inputSchema: GeneralAssistantInputSchema,
        outputSchema: GeneralAssistantOutputSchema,
    },
    async (input) => {
        const response = await prompt(input);
        return { response: response.text };
    }
);
