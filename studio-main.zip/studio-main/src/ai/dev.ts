'use server';
// Flows will be imported for their side effects in this file.
import './flows/medicine-assistant-flow';
import './flows/general-assistant-flow';
