export const firebaseConfig = {
  "projectId": "studio-4944426766-97951",
  "appId": "1:113238097754:web:caa0031bb01f463bc1bd63",
  "apiKey": "AIzaSyD4jruwNqZ2Y5PowT4HbjAnPfQh1hPs-6Y",
  "authDomain": "studio-4944426766-97951.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "113238097754"
};
