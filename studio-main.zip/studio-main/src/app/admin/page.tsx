import AdminDashboard from '@/components/admin/AdminDashboard';
import { getMedicines, getPharmacies } from '@/lib/data';

export default function AdminPage() {
  const initialMedicines = getMedicines();
  const initialPharmacies = getPharmacies();

  return (
    <AdminDashboard
      initialPharmacies={initialPharmacies}
      initialMedicines={initialMedicines}
    />
  );
}
