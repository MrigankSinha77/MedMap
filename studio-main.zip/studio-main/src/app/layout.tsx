import type { Metadata } from 'next';
import './globals.css';
import { cn } from '@/lib/utils';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/contexts/auth-context';
import Header from '@/components/common/Header';
import { AppProvider } from '@/contexts/app-provider';
import { FirebaseClientProvider } from '@/firebase/client-provider';
import ChatWidget from '@/components/chat/ChatWidget';

export const metadata: Metadata = {
  title: 'MedMap',
  description: 'Your reliable medicine and pharmacy finder.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className={cn('min-h-screen bg-background font-body antialiased')}>
        <FirebaseClientProvider>
          <AuthProvider>
            <AppProvider>
              <div className="relative flex min-h-screen flex-col">
                <Header />
                <main className="flex-1">{children}</main>
              </div>
              <ChatWidget />
              <Toaster />
            </AppProvider>
          </AuthProvider>
        </FirebaseClientProvider>
      </body>
    </html>
  );
}
