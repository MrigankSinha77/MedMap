import HomePage from '@/components/home/HomePage';
import { getMedicines, getPharmacies } from '@/lib/data';

export default function Home() {
  // In a real app, you'd fetch this data from an API.
  // For this example, we're getting it from a local file.
  const initialMedicines = getMedicines();
  const initialPharmacies = getPharmacies();

  return (
    <HomePage
      initialMedicines={initialMedicines}
      initialPharmacies={initialPharmacies}
    />
  );
}
