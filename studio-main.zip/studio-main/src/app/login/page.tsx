"use client";

import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, User, UserCheck, Eye } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const ADMIN_ID = '25070122115';

export default function LoginPage() {
  const { user, signInAsSuperAdmin, signInAsPharmacyAdmin, signInAsViewer, signInAsUser } = useAuth();
  const router = useRouter();
  const [isAdminDialogOpen, setAdminDialogOpen] = useState(false);
  const [adminIdInput, setAdminIdInput] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      if(user.role.includes('Admin')) {
        router.push("/admin");
      } else {
        router.push("/");
      }
    }
  }, [user, router]);

  const handleAdminSignInAttempt = () => {
    if (adminIdInput === ADMIN_ID) {
      signInAsSuperAdmin();
      setAdminDialogOpen(false);
    } else {
      toast({
        variant: "destructive",
        title: "Invalid Admin ID",
        description: "The ID you entered is incorrect. Please try again.",
      });
    }
  };

  return (
    <>
      <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center p-4 bg-secondary/30">
        <Card className="w-full max-w-sm animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-2xl font-headline">Welcome to MedMap</CardTitle>
            <CardDescription>
              Please select a role to sign in for demonstration.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <Button onClick={() => setAdminDialogOpen(true)} className="w-full" size="lg">
              <Shield className="mr-2 h-5 w-5" />
              Sign in as Super Admin
            </Button>
            <Button onClick={signInAsPharmacyAdmin} className="w-full" variant="secondary" size="lg">
              <UserCheck className="mr-2 h-5 w-5" />
              Sign in as Pharmacy Admin
            </Button>
            <Button onClick={signInAsViewer} className="w-full" variant="secondary" size="lg">
              <Eye className="mr-2 h-5 w-5" />
              Sign in as Viewer
            </Button>
             <Button onClick={signInAsUser} className="w-full" variant="outline" size="lg">
              <User className="mr-2 h-5 w-5" />
              Sign in as User
            </Button>
          </CardContent>
        </Card>
      </div>

      <Dialog open={isAdminDialogOpen} onOpenChange={setAdminDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Super Admin Sign In</DialogTitle>
            <DialogDescription>
              Please enter the Super Admin ID to proceed.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="admin-id">Admin ID</Label>
              <Input
                id="admin-id"
                placeholder="Enter admin ID"
                value={adminIdInput}
                onChange={(e) => setAdminIdInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAdminSignInAttempt();
                  }
                }}
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="secondary">
                Cancel
              </Button>
            </DialogClose>
            <Button type="button" onClick={handleAdminSignInAttempt}>
              Sign In
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
