"use client";

import React, { createContext, useContext, useEffect, useState } from 'react';
import type { User as AppUser } from '@/lib/types';
import { useRouter } from 'next/navigation';
import { useUser, useAuth as useFirebaseAuth, useFirestore, useMemoFirebase } from '@/firebase';
import { signInAnonymously, signOut as firebaseSignOut } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { useDoc } from '@/firebase/firestore/use-doc';

const SUPER_ADMIN_USER: Omit<AppUser, 'id'> = { name: 'Super Admin', email: 'super@medmap.com', role: 'Super Admin' };
const PHARMACY_ADMIN_USER: Omit<AppUser, 'id'> = { name: 'Pharmacy Admin', email: 'pharmadmin@medmap.com', role: 'Pharmacy Admin' };
const VIEWER_USER: Omit<AppUser, 'id'> = { name: 'Viewer User', email: 'viewer@medmap.com', role: 'Viewer' };
const REGULAR_USER: Omit<AppUser, 'id'> = { name: 'Regular User', email: 'user@medmap.com', role: 'User' };


interface AuthContextType {
  user: AppUser | null;
  loading: boolean;
  signInAsSuperAdmin: () => void;
  signInAsPharmacyAdmin: () => void;
  signInAsViewer: () => void;
  signInAsUser: () => void;
  signOut: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const firebaseAuth = useFirebaseAuth(); // The real auth instance
  const firestore = useFirestore();
  const { user: firebaseUser, isUserLoading: isFirebaseUserLoading } = useUser(); // The real firebase user

  const userProfileRef = useMemoFirebase(() => {
    if (!firestore || !firebaseUser) return null;
    return doc(firestore, 'users', firebaseUser.uid);
  }, [firestore, firebaseUser]);
  
  const { data: userProfile, isLoading: isProfileLoading } = useDoc<AppUser>(userProfileRef);

  const [appUser, setAppUser] = useState<AppUser | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);

  useEffect(() => {
    if (!isFirebaseUserLoading && firebaseUser && userProfile) {
        setAppUser(userProfile);
    } else if (!isFirebaseUserLoading && !firebaseUser) {
        setAppUser(null);
    }
  }, [firebaseUser, isFirebaseUserLoading, userProfile]);

  const handleSignIn = async (userToCreate: Omit<AppUser, 'id'>) => {
    if (!firebaseAuth || !firestore) return;
    setIsSigningIn(true);
    try {
        const userCredential = await signInAnonymously(firebaseAuth);
        const { uid } = userCredential.user;
        const userDocRef = doc(firestore, 'users', uid);
        const newUserProfile: AppUser = {
            ...userToCreate,
            id: uid,
        };
        // This is a crucial write to establish the user's role.
        await setDoc(userDocRef, newUserProfile, { merge: true });

        setAppUser(newUserProfile);
        
        if (newUserProfile.role.includes('Admin')) {
            router.push('/admin');
        } else {
            router.push('/');
        }
    } catch (error) {
        console.error("Sign in failed:", error);
    } finally {
        setIsSigningIn(false);
    }
  };

  const signInAsSuperAdmin = () => handleSignIn(SUPER_ADMIN_USER);
  const signInAsPharmacyAdmin = () => handleSignIn(PHARMACY_ADMIN_USER);
  const signInAsViewer = () => handleSignIn(VIEWER_USER);
  const signInAsUser = () => handleSignIn(REGULAR_USER);

  const signOut = () => {
    if (!firebaseAuth) return;
    firebaseSignOut(firebaseAuth);
    setAppUser(null);
    router.push('/login');
  };

  const loading = isFirebaseUserLoading || isProfileLoading || isSigningIn;

  const value = { user: appUser, loading, signInAsSuperAdmin, signInAsPharmacyAdmin, signInAsViewer, signInAsUser, signOut };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
