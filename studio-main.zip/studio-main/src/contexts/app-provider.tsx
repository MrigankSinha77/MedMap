"use client";

import React, { createContext, useContext, useEffect, useMemo } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import type { CartItem, Medicine } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';

interface AppContextType {
  // Bookmarks
  bookmarkedMedicines: string[];
  addBookmark: (medicineId: string) => void;
  removeBookmark: (medicineId: string) => void;

  // Recent Searches
  recentSearches: string[];
  addRecentSearch: (searchTerm: string) => void;
  clearRecentSearches: () => void;

  // Emergency Mode
  isEmergency: boolean;
  setEmergency: (isEmergency: boolean) => void;

  // Accessibility Mode
  isAccessible: boolean;
  setAccessible: (isAccessible: boolean) => void;

  // Analytics
  searchCounts: Record<string, number>;
  incrementSearchCount: (medicineId: string) => void;

  // Cart
  cart: CartItem[];
  addToCart: (medicine: Medicine, quantity?: number) => void;
  updateCartQuantity: (medicineId: string, quantity: number) => void;
  removeFromCart: (medicineId: string) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [bookmarkedMedicines, setBookmarkedMedicines] = useLocalStorage<string[]>('medmap-bookmarks', []);
  const [recentSearches, setRecentSearches] = useLocalStorage<string[]>('medmap-recent-searches', []);
  const [isEmergency, setEmergency] = useLocalStorage<boolean>('medmap-emergency-mode', false);
  const [isAccessible, setAccessible] = useLocalStorage<boolean>('medmap-accessible-mode', false);
  const [searchCounts, setSearchCounts] = useLocalStorage<Record<string, number>>('medmap-search-counts', {});
  const [cart, setCart] = useLocalStorage<CartItem[]>('medmap-cart', []);
  const { toast } = useToast();

  // Bookmarks
  const addBookmark = (medicineId: string) => {
    setBookmarkedMedicines(prev => [...new Set([...prev, medicineId])]);
  };
  const removeBookmark = (medicineId: string) => {
    setBookmarkedMedicines(prev => prev.filter(id => id !== medicineId));
  };

  // Recent Searches
  const addRecentSearch = (searchTerm: string) => {
    setRecentSearches(prev => {
      const newSearches = [searchTerm, ...prev.filter(s => s.toLowerCase() !== searchTerm.toLowerCase())];
      return newSearches.slice(0, 5); // Keep last 5
    });
  };
  const clearRecentSearches = () => setRecentSearches([]);

  // Analytics
  const incrementSearchCount = (medicineId: string) => {
    setSearchCounts(prev => ({
      ...prev,
      [medicineId]: (prev[medicineId] || 0) + 1,
    }));
  };

  // Cart
  const addToCart = (medicine: Medicine, quantity: number = 1) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === medicine.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === medicine.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prevCart, { id: medicine.id, name: medicine.name, price: medicine.price, quantity }];
    });
    toast({
      title: "Item Added to Cart",
      description: `${medicine.name} has been added to your cart.`,
    })
  };

  const updateCartQuantity = (medicineId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(medicineId);
    } else {
      setCart(prevCart => prevCart.map(item => item.id === medicineId ? { ...item, quantity } : item));
    }
  };

  const removeFromCart = (medicineId: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== medicineId));
  };
  
  const clearCart = () => setCart([]);

  const cartTotal = useMemo(() => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  }, [cart]);

  const cartCount = useMemo(() => {
    return cart.reduce((count, item) => count + item.quantity, 0);
  }, [cart]);


  useEffect(() => {
    if(isAccessible) {
      document.body.classList.add('accessible');
    } else {
      document.body.classList.remove('accessible');
    }
  }, [isAccessible]);

  const value = {
    bookmarkedMedicines,
    addBookmark,
    removeBookmark,
    recentSearches,
    addRecentSearch,
    clearRecentSearches,
    isEmergency,
    setEmergency,
    isAccessible,
    setAccessible,
    searchCounts,
    incrementSearchCount,
    cart,
    addToCart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartTotal,
    cartCount,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
