export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
}

export interface Medicine {
  id: string;
  name: string;
  price: number;
  usage: string;
  dosage: string;
  benefits: string[];
  sideEffects: string[];
  warnings: string[];
  timetable: {
    morning: boolean;
    afternoon: boolean;
    night: boolean;
  };
  isEssential: boolean;
  ageWarnings: {
    child: string[];
    adult: string[];
    elderly: string[];
  };
  interactionWarnings: string[];
}

export interface PharmacyMedicine {
  medicineId: string;
  stock: number;
  available: boolean;
}

export interface Pharmacy {
  id: string;
  name: string;
  city: string;
  medicines: PharmacyMedicine[];
  imageId: string;
  isAlwaysOpen: boolean;
}

export interface ActivityLog {
  id: string;
  user: {
    name: string;
    role: User['role'];
  };
  action: string;
  timestamp: Date;
}

export interface CartItem {
    id: string; // medicine id
    name: string;
    price: number;
    quantity: number;
}

export interface Order {
    id?: string;
    userId: string;
    customerName: string;
    customerPhone: string;
    customerAddress: string;
    items: OrderItem[];
    totalAmount: number;
    paymentMethod: 'Cash on Delivery' | 'Pay at Pharmacy' | 'Online Payment';
    status: 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
    orderDate: Date;
}

export interface OrderItem {
    medicineId: string;
    name: string;
    quantity: number;
    price: number;
}
