import type { Medicine, Pharmacy } from './types';

const medicines: Medicine[] = [
  {
    id: 'med1',
    name: 'Paracetamol',
    price: 5,
    usage: 'For relief of mild to moderate pain and to reduce fever.',
    dosage: '1-2 tablets every 4-6 hours as needed. Do not exceed 8 tablets in 24 hours.',
    benefits: ['Pain relief', 'Fever reduction', 'Generally well-tolerated'],
    sideEffects: ['Nausea', 'Allergic reactions', 'Skin rash (rare)'],
    warnings: ['Do not take with other products containing paracetamol.'],
    timetable: { morning: true, afternoon: true, night: true },
    isEssential: true,
    ageWarnings: {
      child: ["Use pediatric version. Dosage is weight-dependent."],
      adult: [],
      elderly: ["Consult a doctor if you have liver or kidney problems."],
    },
    interactionWarnings: ["Avoid long-term use with alcohol to prevent liver damage."],
  },
  {
    id: 'med2',
    name: 'Ibuprofen',
    price: 8,
    usage: 'For relief of pain, inflammation, and fever.',
    dosage: '1-2 tablets every 4-6 hours with food. Do not exceed 6 tablets in 24 hours.',
    benefits: ['Anti-inflammatory', 'Pain relief', 'Reduces swelling'],
    sideEffects: ['Stomach upset', 'Heartburn', 'Dizziness'],
    warnings: ['Do not take if you have a history of stomach ulcers or kidney disease.'],
    timetable: { morning: true, afternoon: true, night: false },
    isEssential: true,
    ageWarnings: {
      child: ["Not recommended for infants under 6 months."],
      adult: [],
      elderly: ["Increased risk of stomach bleeding. Use with caution."],
    },
    interactionWarnings: ["Avoid with blood pressure medicines.", "Do not take with Aspirin or other NSAIDs."],
  },
  {
    id: 'med3',
    name: 'Amoxicillin',
    price: 15,
    usage: 'A penicillin antibiotic that fights bacteria.',
    dosage: 'As prescribed by the doctor. Usually one capsule every 8 or 12 hours.',
    benefits: ['Treats bacterial infections', 'Effective against a wide range of bacteria'],
    sideEffects: ['Diarrhea', 'Nausea', 'Yeast infections'],
    warnings: ['Complete the full course even if you feel better.'],
    timetable: { morning: true, afternoon: false, night: true },
    isEssential: false,
    ageWarnings: {
      child: ["Dosage is based on weight."],
      adult: [],
      elderly: ["May require dose adjustment in renal impairment."],
    },
    interactionWarnings: ["Inform your doctor if you are allergic to penicillin.", "May decrease effectiveness of birth control pills."],
  },
  {
    id: 'med4',
    name: 'Cetirizine',
    price: 10,
    usage: 'An antihistamine used to relieve allergy symptoms.',
    dosage: 'One tablet once daily.',
    benefits: ['Relieves sneezing, runny nose, and itchy eyes', 'Non-drowsy for most people'],
    sideEffects: ['Drowsiness', 'Dry mouth', 'Tiredness'],
    warnings: ['Avoid alcohol while taking this medication.'],
    timetable: { morning: false, afternoon: false, night: true },
    isEssential: false,
    ageWarnings: {
      child: ["Liquid form available for children over 2 years."],
      adult: [],
      elderly: ["May cause more pronounced drowsiness."],
    },
    interactionWarnings: ["Consult a doctor if you are pregnant or breastfeeding."],
  },
];

const pharmacies: Pharmacy[] = [
  {
    id: 'pharma1',
    name: 'City Health Pharmacy',
    city: 'Metropolis',
    imageId: 'pharmacy-1',
    medicines: [
      { medicineId: 'med1', stock: 150, available: true },
      { medicineId: 'med2', stock: 80, available: true },
      { medicineId: 'med4', stock: 200, available: true },
    ],
    isAlwaysOpen: true,
  },
  {
    id: 'pharma2',
    name: 'Wellness Drug Store',
    city: 'Star City',
    imageId: 'pharmacy-2',
    medicines: [
      { medicineId: 'med1', stock: 200, available: true },
      { medicineId: 'med2', stock: 0, available: false },
      { medicineId: 'med3', stock: 50, available: true },
    ],
    isAlwaysOpen: false,
  },
  {
    id: 'pharma3',
    name: 'Suburbia Meds',
    city: 'Central City',
    imageId: 'pharmacy-3',
    medicines: [
      { medicineId: 'med2', stock: 120, available: true },
      { medicineId: 'med3', stock: 90, available: true },
      { medicineId: 'med4', stock: 30, available: true },
    ],
    isAlwaysOpen: true,
  },
  {
    id: 'pharma4',
    name: 'Apex Pharmaceuticals',
    city: 'Gotham',
    imageId: 'pharmacy-4',
    medicines: [
      { medicineId: 'med1', stock: 300, available: true },
      { medicineId: 'med3', stock: 25, available: true },
    ],
    isAlwaysOpen: false,
  },
];

export const getMedicines = () => medicines;
export const getPharmacies = () => pharmacies;
