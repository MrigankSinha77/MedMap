"use client";

import React, { useState, useMemo, useEffect } from 'react';
import type { Medicine, Pharmacy } from '@/lib/types';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Image from 'next/image';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Pill, Search, Store, Building, Info, Bookmark, History, X, LifeBuoy, ShoppingCart } from 'lucide-react';
import MedicineInfoSheet from '@/components/medicine/MedicineInfoSheet';
import { useApp } from '@/contexts/app-provider';
import { Skeleton } from '../ui/skeleton';

interface HomePageProps {
  initialMedicines: Medicine[];
  initialPharmacies: Pharmacy[];
}

function PharmacyCardSkeleton() {
  return (
    <Card className="overflow-hidden">
      <Skeleton className="h-48 w-full" />
      <CardHeader>
        <Skeleton className="h-8 w-3/4" />
        <Skeleton className="h-4 w-1/2 mt-2" />
      </CardHeader>
      <CardContent className="space-y-4">
        <Skeleton className="h-5 w-1/3" />
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <div className="space-y-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-16" />
            </div>
            <Skeleton className="h-8 w-20" />
          </div>
          <div className="flex justify-between items-center">
            <div className="space-y-2">
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-12" />
            </div>
            <Skeleton className="h-8 w-20" />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function EmptyState() {
  return (
    <div className="text-center py-16 bg-card rounded-lg shadow-sm border border-dashed animate-fade-in-up">
      <Search className="mx-auto h-16 w-16 text-muted-foreground/30 mb-4" />
      <h3 className="text-xl font-semibold">No Pharmacies Found</h3>
      <p className="text-muted-foreground mt-2 max-w-md mx-auto">
        We couldn't find any pharmacies matching your search. Try a different term or clear your filters.
      </p>
    </div>
  )
}


export default function HomePage({ initialMedicines, initialPharmacies }: HomePageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);
  const [isSheetOpen, setSheetOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const {
    isEmergency,
    bookmarkedMedicines,
    addBookmark,
    removeBookmark,
    recentSearches,
    addRecentSearch,
    clearRecentSearches,
    incrementSearchCount,
    addToCart,
  } = useApp();

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 750);
    return () => clearTimeout(timer);
  }, []);

  const filteredPharmacies = useMemo(() => {
    let pharmacies = initialPharmacies;

    if (isEmergency) {
      pharmacies = pharmacies.filter(p => p.isAlwaysOpen && p.medicines.some(pm => {
        const med = initialMedicines.find(m => m.id === pm.medicineId);
        return med?.isEssential && pm.available;
      }));
    }

    if (!searchQuery) {
      return pharmacies;
    }

    const lowerCaseQuery = searchQuery.toLowerCase();
    return pharmacies.filter(pharmacy => {
      const pharmacyNameMatch = pharmacy.name.toLowerCase().includes(lowerCaseQuery);
      const cityNameMatch = pharmacy.city.toLowerCase().includes(lowerCaseQuery);
      const medicineMatch = pharmacy.medicines.some(pm => {
        const medicine = initialMedicines.find(m => m.id === pm.medicineId);
        return medicine?.name.toLowerCase().includes(lowerCaseQuery);
      });
      return pharmacyNameMatch || cityNameMatch || medicineMatch;
    });
  }, [searchQuery, initialPharmacies, initialMedicines, isEmergency]);

  const handleSearchSubmit = (query: string) => {
    const trimmedQuery = query.trim();
    if(trimmedQuery) {
      setSearchQuery(trimmedQuery);
      addRecentSearch(trimmedQuery);
      const matchedMedicine = initialMedicines.find(m => m.name.toLowerCase() === trimmedQuery.toLowerCase());
      if(matchedMedicine) {
        incrementSearchCount(matchedMedicine.id);
      }
    }
  };
  
  const handleViewDetails = (medicine: Medicine) => {
    setSelectedMedicine(medicine);
    setSheetOpen(true);
  };

  const bookmarkedMedsData = useMemo(() => initialMedicines.filter(m => bookmarkedMedicines.includes(m.id)), [bookmarkedMedicines, initialMedicines]);

  return (
    <div className="container mx-auto p-4 md:p-8">
      {isEmergency && (
        <div className="mb-8 p-4 rounded-lg bg-destructive/10 border border-destructive text-destructive-foreground flex items-center gap-4">
          <LifeBuoy className="h-8 w-8 text-destructive" />
          <div>
            <h3 className="font-bold text-lg text-destructive">Emergency Mode Activated</h3>
            <p className="text-sm">Showing only essential medicines from pharmacies marked as always available.</p>
          </div>
        </div>
      )}
      <section className="mb-12 text-center">
        <h1 className="text-4xl md:text-5xl font-headline font-bold text-foreground mb-3 animate-fade-in-up">Your Trusted Medicine Finder</h1>
        <p className="text-lg text-muted-foreground mb-8 max-w-3xl mx-auto animate-fade-in-up" style={{ animationDelay: '100ms' }}>
          Quickly locate pharmacies, check medicine availability, and get important drug information.
        </p>
        <div className="relative max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: '200ms' }}>
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search by pharmacy, city, or medicine name..."
            className="w-full pl-12 h-14 text-base rounded-full shadow-lg"
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleSearchSubmit(e.currentTarget.value);
              }
            }}
          />
        </div>
        {recentSearches.length > 0 && (
          <div className="mt-4 flex gap-2 justify-center flex-wrap max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: '300ms' }}>
            <h4 className="text-sm font-semibold flex items-center gap-1.5 text-muted-foreground"><History className="w-4 h-4" /> Recent:</h4>
            {recentSearches.map((term, i) => (
              <Button key={i} size="sm" variant="outline" className="rounded-full" onClick={() => handleSearchSubmit(term)}>
                {term}
              </Button>
            ))}
             <Button size="sm" variant="ghost" className="rounded-full" onClick={clearRecentSearches}>
                <X className="w-4 h-4"/>
              </Button>
          </div>
        )}
      </section>

      {bookmarkedMedsData.length > 0 && !isEmergency && (
        <section className="mb-12">
            <h2 className="text-3xl font-headline font-bold mb-6 flex items-center gap-3">
              <Bookmark className="w-8 h-8 text-primary" />
              Your Bookmarks
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {bookmarkedMedsData.map(med => (
                <Card key={med.id} className="text-center p-4 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleViewDetails(med)}>
                  <Pill className="h-8 w-8 mx-auto text-primary mb-2" />
                  <p className="font-semibold">{med.name}</p>
                </Card>
              ))}
            </div>
        </section>
      )}

      <section>
        <h2 className="text-3xl font-headline font-bold mb-6 flex items-center gap-3">
          <Store className="w-8 h-8 text-primary" />
          {isEmergency ? 'Available Emergency Pharmacies' : 'Available Pharmacies'}
        </h2>
        {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(3)].map((_, i) => <PharmacyCardSkeleton key={i} />)}
            </div>
        ) : filteredPharmacies.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPharmacies.map((pharmacy, index) => {
              const image = PlaceHolderImages.find(img => img.id === pharmacy.imageId);
              return (
                <Card 
                  key={pharmacy.id} 
                  className="overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 animate-fade-in-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <CardHeader className="p-0">
                    {image && (
                      <div className="relative h-48 w-full">
                         <Image
                            src={image.imageUrl}
                            alt={image.description}
                            data-ai-hint={image.imageHint}
                            fill
                            className="object-cover"
                         />
                         {pharmacy.isAlwaysOpen && (
                          <Badge className="absolute top-2 right-2 bg-primary">24/7 Open</Badge>
                         )}
                      </div>
                    )}
                     <div className="p-6 pb-2">
                      <CardTitle className="font-headline text-2xl">{pharmacy.name}</CardTitle>
                      <p className="text-muted-foreground flex items-center gap-2 mt-1">
                        <Building className="w-4 h-4" /> {pharmacy.city}
                      </p>
                     </div>
                  </CardHeader>
                  <CardContent>
                    <h4 className="font-semibold mb-3 flex items-center gap-2"><Pill className="w-4 h-4 text-primary"/>Available Medicines</h4>
                    <div className="space-y-3">
                      {pharmacy.medicines
                        .filter(pm => !isEmergency || initialMedicines.find(m => m.id === pm.medicineId)?.isEssential)
                        .map(pm => {
                          const medicine = initialMedicines.find(m => m.id === pm.medicineId);
                          if (!medicine) return null;
                          const isBookmarked = bookmarkedMedicines.includes(medicine.id);
                          return (
                            <div key={pm.medicineId} className="flex justify-between items-center bg-secondary/50 p-3 rounded-lg">
                              <div>
                                <span className="font-medium">{medicine.name}</span>
                                <div className="flex items-center gap-2 mt-1">
                                  {pm.available ? (
                                    <Badge variant="default" className="bg-green-600 hover:bg-green-700">In Stock</Badge>
                                  ) : (
                                    <Badge variant="destructive">Out of Stock</Badge>
                                  )}
                                  <span className="text-sm text-muted-foreground">Qty: {pm.stock}</span>
                                </div>
                              </div>
                              <div className='flex items-center'>
                                <Button size="icon" variant="ghost" onClick={() => handleViewDetails(medicine)}>
                                  <Info className="h-5 w-5" />
                                </Button>
                                {pm.available && (
                                  <Button size="icon" variant="ghost" onClick={() => addToCart(medicine)}>
                                    <ShoppingCart className="h-5 w-5 text-primary" />
                                  </Button>
                                )}
                              </div>
                            </div>
                          );
                      })}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <EmptyState />
        )}
      </section>

      {selectedMedicine && (
        <MedicineInfoSheet
          medicine={selectedMedicine}
          isOpen={isSheetOpen}
          onOpenChange={setSheetOpen}
        />
      )}
    </div>
  );
}
