"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useApp } from '@/contexts/app-provider';
import { useAuth } from '@/contexts/auth-context';
import { useToast } from '@/hooks/use-toast';
import { useFirestore } from '@/firebase';
import { collection, doc } from 'firebase/firestore';
import type { Order } from '@/lib/types';
import { addDocumentNonBlocking, setDocumentNonBlocking } from '@/firebase';

interface CheckoutDialogProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
}

export default function CheckoutDialog({ isOpen, onOpenChange }: CheckoutDialogProps) {
  const { user } = useAuth();
  const { cart, cartTotal, clearCart } = useApp();
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash on Delivery' | 'Pay at Pharmacy' | 'Online Payment'>('Cash on Delivery');
  const [isSubmitting, setSubmitting] = useState(false);

  const { toast } = useToast();
  const firestore = useFirestore();
  const router = useRouter();

  useEffect(() => {
    if (user?.name) {
      setCustomerName(user.name);
    }
  }, [user]);

  const handlePlaceOrder = async () => {
    if (!user) {
      toast({ variant: 'destructive', title: 'Not Logged In', description: 'You must be logged in to place an order.' });
      return;
    }
    if (!customerName || !customerPhone || !customerAddress) {
      toast({ variant: 'destructive', title: 'Missing Information', description: 'Please fill out all customer details.' });
      return;
    }
    if (!firestore) {
      toast({ variant: 'destructive', title: 'Connection Error', description: 'Could not connect to the database.' });
      return;
    }

    setSubmitting(true);

    const newOrder: Omit<Order, 'id'> = {
      userId: user.id,
      customerName,
      customerPhone,
      customerAddress,
      items: cart.map(item => ({ medicineId: item.id, name: item.name, quantity: item.quantity, price: item.price })),
      totalAmount: cartTotal,
      paymentMethod,
      status: 'Pending',
      orderDate: new Date(),
    };

    try {
      const ordersCollection = collection(firestore, 'orders');
      
      // We are writing to two locations for easy querying for both user and admin
      // The first write to the global collection returns a docRef with the new ID
      const docRef = await addDocumentNonBlocking(ordersCollection, newOrder);
      
      if (docRef) {
        // The second write uses that ID to create a document in the user's subcollection
        const userOrderDocRef = doc(firestore, 'users', user.id, 'orders', docRef.id);
        setDocumentNonBlocking(userOrderDocRef, newOrder, {});
      } else {
        throw new Error('Failed to get a document reference from the first write.');
      }

      toast({
        title: 'Order Placed!',
        description: 'Your order has been successfully placed.',
      });
      clearCart();
      onOpenChange(false);
      router.push('/order-success');
    } catch (error) {
      console.error('Order placement error:', error);
      toast({
        variant: 'destructive',
        title: 'Order Failed',
        description: 'There was a problem placing your order. Please try again.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-2xl font-headline">Checkout</DialogTitle>
          <DialogDescription>
            Please confirm your details and payment method to place the order.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-6 py-4">
          <div className="space-y-4">
            <h3 className="font-semibold">Shipping Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" value={customerName} onChange={e => setCustomerName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" type="tel" value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Shipping Address</Label>
              <Input id="address" value={customerAddress} onChange={e => setCustomerAddress(e.target.value)} />
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="font-semibold">Payment Method</h3>
            <RadioGroup value={paymentMethod} onValueChange={value => setPaymentMethod(value as any)}>
              <div className="flex items-center space-x-2 rounded-md border p-3">
                <RadioGroupItem value="Cash on Delivery" id="cod" />
                <Label htmlFor="cod" className="flex-1">Cash on Delivery</Label>
              </div>
              <div className="flex items-center space-x-2 rounded-md border p-3">
                <RadioGroupItem value="Pay at Pharmacy" id="pap" />
                <Label htmlFor="pap" className="flex-1">Pay at Pharmacy</Label>
              </div>
              <div className="flex items-center space-x-2 rounded-md border p-3 bg-muted/50 cursor-not-allowed">
                <RadioGroupItem value="Online Payment" id="op" disabled />
                <Label htmlFor="op" className="flex-1 text-muted-foreground">Online Payment (Coming Soon)</Label>
              </div>
            </RadioGroup>
          </div>
          <div className="p-4 bg-secondary/50 rounded-lg space-y-2">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>${cartTotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span className="text-green-600">Free</span>
            </div>
            <div className="flex justify-between font-bold text-lg border-t pt-2 mt-2">
              <span>Total</span>
              <span>${cartTotal.toFixed(2)}</span>
            </div>
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button" variant="outline" disabled={isSubmitting}>
              Cancel
            </Button>
          </DialogClose>
          <Button type="button" onClick={handlePlaceOrder} disabled={isSubmitting}>
            {isSubmitting ? 'Placing Order...' : 'Place Order'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
