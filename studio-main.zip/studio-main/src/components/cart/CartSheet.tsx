"use client";

import { useState } from 'react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
  SheetClose
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { useApp } from '@/contexts/app-provider';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Trash2, ShoppingCart } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import CheckoutDialog from './CheckoutDialog';

interface CartSheetProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
}

export default function CartSheet({ isOpen, onOpenChange }: CartSheetProps) {
  const { cart, updateCartQuantity, removeFromCart, cartTotal, cartCount } = useApp();
  const [isCheckoutOpen, setCheckoutOpen] = useState(false);

  const handleCheckout = () => {
    onOpenChange(false); // Close cart sheet
    setCheckoutOpen(true);
  }

  return (
    <>
      <Sheet open={isOpen} onOpenChange={onOpenChange}>
        <SheetContent className="w-full sm:max-w-md flex flex-col">
          <SheetHeader>
            <SheetTitle className="text-2xl font-headline flex items-center gap-3">
              <ShoppingCart className="w-6 h-6" /> Your Shopping Cart
            </SheetTitle>
            <SheetDescription>
              Review your items and proceed to checkout.
            </SheetDescription>
          </SheetHeader>

          {cartCount > 0 ? (
            <>
              <ScrollArea className="flex-1 -mx-6">
                <div className="px-6 py-2 space-y-4">
                  {cart.map(item => (
                    <div key={item.id} className="flex items-center gap-4">
                      <div className="flex-1">
                        <p className="font-semibold">{item.name}</p>
                        <p className="text-sm text-muted-foreground">${item.price.toFixed(2)} each</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={e => updateCartQuantity(item.id, parseInt(e.target.value))}
                          className="h-9 w-16 text-center"
                        />
                        <Button variant="ghost" size="icon" className="text-destructive h-9 w-9" onClick={() => removeFromCart(item.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              <SheetFooter className="mt-auto border-t pt-4 space-y-4">
                <div className="flex justify-between items-center text-lg font-semibold">
                  <span>Subtotal</span>
                  <span>${cartTotal.toFixed(2)}</span>
                </div>
                <Button size="lg" className="w-full" onClick={handleCheckout}>
                  Proceed to Checkout
                </Button>
                <SheetClose asChild>
                    <Button variant="outline" className="w-full">
                        Continue Shopping
                    </Button>
                </SheetClose>
              </SheetFooter>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center gap-4">
                <ShoppingCart className="w-16 h-16 text-muted-foreground/30" />
                <h3 className="font-semibold text-xl">Your cart is empty</h3>
                <p className="text-muted-foreground">Add some medicines to get started.</p>
                 <SheetClose asChild>
                    <Button variant="outline">
                        Start Shopping
                    </Button>
                </SheetClose>
            </div>
          )}
        </SheetContent>
      </Sheet>
      
      <CheckoutDialog isOpen={isCheckoutOpen} onOpenChange={setCheckoutOpen} />
    </>
  );
}
