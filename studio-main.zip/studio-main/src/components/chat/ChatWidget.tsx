'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Bot, MessageSquare, Send, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { useAuth } from '@/contexts/auth-context';
import { generalAssistant } from '@/ai/flows/general-assistant-flow';
import { Separator } from '../ui/separator';

type Message = {
  id: string;
  text: string;
  sender: 'user' | 'bot';
}

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  const getInitials = (name: string) => {
    if (!name) return 'U';
    return name.split(" ").map((n) => n[0]).join("");
  };

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([
        { id: 'init', text: `Hi! I'm the MedMap assistant. How can I help you today?`, sender: 'bot' }
      ]);
    }
  }, [isOpen, messages.length]);

  useEffect(() => {
    if (scrollAreaRef.current) {
        scrollAreaRef.current.scrollTo({ top: scrollAreaRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages]);

  const handleSubmit = async () => {
    const userQuestion = input;
    if (!userQuestion.trim()) return;

    const newUserMessage: Message = { id: `user-${Date.now()}`, text: userQuestion, sender: 'user' };
    setMessages(prev => [...prev, newUserMessage]);
    setInput('');
    setIsLoading(true);

    try {
        const aiResponse = await generalAssistant({ question: userQuestion });
        const newBotMessage: Message = { id: `bot-${Date.now()}`, text: aiResponse.response, sender: 'bot' };
        setMessages(prev => [...prev, newBotMessage]);
    } catch (error) {
        console.error("AI Assistant Error:", error);
        const errorMessage: Message = { id: `bot-error-${Date.now()}`, text: "Sorry, I'm having trouble connecting. Please try again later.", sender: 'bot' };
        setMessages(prev => [...prev, errorMessage]);
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="default"
          className="fixed bottom-6 right-6 h-16 w-16 rounded-full shadow-lg z-50 flex items-center justify-center"
        >
          {isOpen ? <X className="w-8 h-8" /> : <MessageSquare className="w-8 h-8" />}
          <span className="sr-only">Toggle Chat</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent
        side="top"
        align="end"
        className="w-[90vw] max-w-sm h-[70vh] max-h-[500px] p-0 flex flex-col mb-2"
      >
        <div className="p-4 border-b">
          <h3 className="font-semibold text-lg flex items-center gap-2">
            <Bot className="text-primary"/>
            MedMap Assistant
          </h3>
          <p className="text-sm text-muted-foreground">Ask me anything about the app!</p>
        </div>
        
        <ScrollArea className="flex-1" viewportRef={scrollAreaRef}>
          <div className="p-4 space-y-4">
            {messages.map((message) => (
                <div key={message.id} className={cn('flex items-end gap-2', message.sender === 'user' ? 'justify-end' : 'justify-start')}>
                    {message.sender === 'bot' && (
                        <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="w-5 h-5"/></AvatarFallback>
                        </Avatar>
                    )}
                    <div className={cn(
                        'max-w-[80%] rounded-lg px-3 py-2 text-sm whitespace-pre-wrap shadow-sm',
                        message.sender === 'user' ? 'bg-primary text-primary-foreground' : 'bg-background'
                    )}>
                        {message.text.split('---').map((part, index) => (
                            index === 1 ? <p key={index} className="text-xs opacity-80 mt-2 pt-2 border-t border-t-white/20">{part}</p> : <p key={index}>{part}</p>
                        ))}
                    </div>
                     {message.sender === 'user' && user && (
                        <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-muted text-muted-foreground font-bold text-xs">{getInitials(user.name)}</AvatarFallback>
                        </Avatar>
                    )}
                </div>
            ))}
            {isLoading && (
                <div className="flex items-end gap-2 justify-start">
                    <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="w-5 h-5"/></AvatarFallback>
                    </Avatar>
                    <div className="bg-background rounded-lg px-3 py-2 shadow-sm">
                        <div className="flex items-center gap-1.5">
                            <span className="h-2 w-2 bg-muted-foreground rounded-full animate-pulse [animation-delay:-0.3s]"></span>
                            <span className="h-2 w-2 bg-muted-foreground rounded-full animate-pulse [animation-delay:-0.15s]"></span>
                            <span className="h-2 w-2 bg-muted-foreground rounded-full animate-pulse"></span>
                        </div>
                    </div>
                </div>
            )}
          </div>
        </ScrollArea>
        
        <Separator />

        <div className="p-4">
          <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); handleSubmit(); }}>
              <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask a question..."
                  disabled={isLoading}
                  className="h-10"
              />
              <Button type="submit" size="icon" disabled={isLoading || !input.trim()}>
                  <Send className="w-4 h-4" />
              </Button>
          </form>
        </div>
      </PopoverContent>
    </Popover>
  );
}
