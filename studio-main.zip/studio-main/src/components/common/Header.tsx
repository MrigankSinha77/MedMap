"use client";

import Link from "next/link";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { LogOut, Shield, Zap, Glasses, Siren, UploadCloud, ShoppingCart } from "lucide-react";
import Logo from "../icons/Logo";
import { useApp } from "@/contexts/app-provider";
import { Switch } from "../ui/switch";
import { Label } from "../ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { useState } from "react";
import { Input } from "../ui/input";
import { useToast } from "@/hooks/use-toast";
import CartSheet from "../cart/CartSheet";

export default function Header() {
  const { user, signOut, loading } = useAuth();
  const { isEmergency, setEmergency, isAccessible, setAccessible, cartCount } = useApp();
  const [isPrescriptionDialogOpen, setPrescriptionDialogOpen] = useState(false);
  const [isConsultDialogOpen, setConsultDialogOpen] = useState(false);
  const [isCartOpen, setCartOpen] = useState(false);
  const { toast } = useToast();

  const getInitials = (name: string) => {
    if (!name) return '';
    return name
      .split(" ")
      .map((n) => n[0])
      .join("");
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      toast({
        title: "Upload Started",
        description: `Your file "${file.name}" is being uploaded. This is a UI-only feature.`,
      });
      setPrescriptionDialogOpen(false);
    }
  };

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <Logo className="text-primary" />
            <span className="font-headline text-xl font-bold text-foreground">
              MedMap
            </span>
          </Link>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-4">
              <Button variant="outline" size="sm" onClick={() => setConsultDialogOpen(true)}>
                <Zap className="mr-2 h-4 w-4"/>
                Consult Online
              </Button>
              <Button variant="outline" size="sm" onClick={() => setPrescriptionDialogOpen(true)}>
                <UploadCloud className="mr-2 h-4 w-4"/>
                Upload Prescription
              </Button>
            </div>
            
            <div className="flex items-center space-x-2">
                <Switch id="emergency-mode" checked={isEmergency} onCheckedChange={setEmergency} />
                <Label htmlFor="emergency-mode" className="flex items-center gap-1.5 text-sm">
                  <Siren className={`h-4 w-4 transition-colors ${isEmergency ? 'text-destructive' : 'text-muted-foreground'}`}/>
                  <span className="hidden sm:inline">Emergency</span>
                </Label>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Glasses />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-64" align="end">
                <DropdownMenuLabel>Accessibility Settings</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <div className="p-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="accessibility-mode" className="pr-2">High Contrast & Large Fonts</Label>
                    <Switch id="accessibility-mode" checked={isAccessible} onCheckedChange={setAccessible} />
                  </div>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="ghost" size="icon" className="relative" onClick={() => setCartOpen(true)}>
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                  {cartCount}
                </span>
              )}
            </Button>

            {!loading &&
              (user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                      <Avatar className="h-10 w-10 border-2 border-primary/50">
                        <AvatarFallback className="bg-primary text-primary-foreground font-bold">
                          {getInitials(user.name)}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <DropdownMenuLabel className="font-normal">
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none">{user.name}</p>
                        <p className="text-xs leading-none text-muted-foreground">
                          {user.email} {user.role && `(${user.role})`}
                        </p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    {user.role?.includes('Admin') && (
                      <DropdownMenuItem asChild>
                        <Link href="/admin">
                          <Shield className="mr-2 h-4 w-4" />
                          <span>Admin Panel</span>
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={signOut}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Log out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button asChild>
                  <Link href="/login">Login</Link>
                </Button>
              ))}
          </div>
        </div>
      </header>

      <CartSheet isOpen={isCartOpen} onOpenChange={setCartOpen} />

      <Dialog open={isPrescriptionDialogOpen} onOpenChange={setPrescriptionDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Upload Prescription</DialogTitle>
            <DialogDescription>
              Upload an image of your prescription. This feature is for demonstration only.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Input type="file" accept="image/*" onChange={handleFileUpload} />
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="secondary">Cancel</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog open={isConsultDialogOpen} onOpenChange={setConsultDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Online Consultation</DialogTitle>
            <DialogDescription>
              This is a placeholder for a future doctor consultation feature.
            </DialogDescription>
          </DialogHeader>
          <div className="py-8 text-center text-muted-foreground">
            <p>Connecting you to a doctor...</p>
            <p className="text-sm">(This is a mock UI)</p>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button">Close</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
