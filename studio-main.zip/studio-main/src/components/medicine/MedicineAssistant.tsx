"use client";

import { useState, useRef, useEffect } from 'react';
import type { Medicine } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Bot, Send, Sparkles } from 'lucide-react';
import { medicineAssistant } from '@/ai/flows/medicine-assistant-flow';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { useAuth } from '@/contexts/auth-context';

interface MedicineAssistantProps {
  medicine: Medicine;
}

type Message = {
  id: string;
  text: string;
  sender: 'user' | 'bot';
}

const suggestedQuestions = [
    "When should I take this?",
    "What are the main benefits?",
    "Are there any side effects I should know about?",
    "Any important warnings for this medicine?",
];

export default function MedicineAssistant({ medicine }: MedicineAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  const getInitials = (name: string) => {
    if (!name) return 'U';
    return name.split(" ").map((n) => n[0]).join("");
  };

  useEffect(() => {
    setMessages([
        { id: 'init', text: `Hi! I'm PharmaBot. How can I help you with ${medicine.name}?`, sender: 'bot' }
    ]);
  }, [medicine.name]);

  useEffect(() => {
    if (scrollAreaRef.current) {
        scrollAreaRef.current.scrollTo({ top: scrollAreaRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages]);

  const handleSubmit = async (question?: string) => {
    const userQuestion = question || input;
    if (!userQuestion.trim()) return;

    const newUserMessage: Message = { id: `user-${Date.now()}`, text: userQuestion, sender: 'user' };
    setMessages(prev => [...prev, newUserMessage]);
    setInput('');
    setIsLoading(true);

    try {
        const aiResponse = await medicineAssistant({ medicine, question: userQuestion });
        const newBotMessage: Message = { id: `bot-${Date.now()}`, text: aiResponse.response, sender: 'bot' };
        setMessages(prev => [...prev, newBotMessage]);
    } catch (error) {
        console.error("AI Assistant Error:", error);
        const errorMessage: Message = { id: `bot-error-${Date.now()}`, text: "Sorry, I'm having trouble connecting. Please try again later.", sender: 'bot' };
        setMessages(prev => [...prev, errorMessage]);
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <div className="mt-2 p-4 border rounded-lg bg-secondary/30 flex flex-col h-full">
        <div className="flex items-center gap-3 mb-4">
            <Avatar className="h-10 w-10">
                <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="w-6 h-6"/></AvatarFallback>
            </Avatar>
            <div>
                <h4 className="font-semibold text-lg">AI Medicine Assistant</h4>
                <p className="text-sm text-muted-foreground">Ask anything about {medicine.name}</p>
            </div>
        </div>

        <ScrollArea className="flex-1 -mx-4" viewportRef={scrollAreaRef}>
          <div className="px-4 space-y-4">
            {messages.map((message) => (
                <div key={message.id} className={cn('flex items-end gap-2', message.sender === 'user' ? 'justify-end' : 'justify-start')}>
                    {message.sender === 'bot' && (
                        <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="w-5 h-5"/></AvatarFallback>
                        </Avatar>
                    )}
                    <div className={cn(
                        'max-w-[80%] rounded-lg px-3 py-2 text-sm whitespace-pre-wrap shadow-sm',
                        message.sender === 'user' ? 'bg-primary text-primary-foreground' : 'bg-background'
                    )}>
                        {message.text.split('---').map((part, index) => (
                            index === 1 ? <p key={index} className="text-xs opacity-80 mt-2 pt-2 border-t border-t-white/20">{part}</p> : <p key={index}>{part}</p>
                        ))}
                    </div>
                     {message.sender === 'user' && user && (
                        <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-muted text-muted-foreground font-bold text-xs">{getInitials(user.name)}</AvatarFallback>
                        </Avatar>
                    )}
                </div>
            ))}
            {isLoading && (
                <div className="flex items-end gap-2 justify-start">
                    <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-primary text-primary-foreground"><Bot className="w-5 h-5"/></AvatarFallback>
                    </Avatar>
                    <div className="bg-background rounded-lg px-3 py-2 shadow-sm">
                        <div className="flex items-center gap-1.5">
                            <span className="h-2 w-2 bg-muted-foreground rounded-full animate-pulse [animation-delay:-0.3s]"></span>
                            <span className="h-2 w-2 bg-muted-foreground rounded-full animate-pulse [animation-delay:-0.15s]"></span>
                            <span className="h-2 w-2 bg-muted-foreground rounded-full animate-pulse"></span>
                        </div>
                    </div>
                </div>
            )}
          </div>
        </ScrollArea>
        
        <div className="pt-2 mt-auto">
            {!isLoading && (
                <div className="flex gap-2 flex-wrap mb-2">
                    {suggestedQuestions.map((q, i) => (
                        <Button key={i} size="sm" variant="outline" className="rounded-full text-xs" onClick={() => handleSubmit(q)}>
                           <Sparkles className="w-3 h-3 mr-1.5" /> {q}
                        </Button>
                    ))}
                </div>
            )}

            <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); handleSubmit(); }}>
                <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask a question..."
                    disabled={isLoading}
                    className="h-10"
                />
                <Button type="submit" size="icon" disabled={isLoading || !input.trim()}>
                    <Send className="w-4 h-4" />
                </Button>
            </form>
             <div className="w-full text-center px-2 pt-2">
                <p className="text-xs text-muted-foreground">PharmaBot can make mistakes. Always consult a healthcare professional.</p>
            </div>
        </div>
    </div>
  );
}
