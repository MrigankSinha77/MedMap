"use client";

import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from '@/components/ui/sheet';
import type { Medicine } from '@/lib/types';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Clock, AlertTriangle, Sunrise, Sunset, Sun, ShieldAlert, HeartPulse, Baby, User, UserCog, Ban, Drama, Sparkles } from 'lucide-react';
import { Separator } from '../ui/separator';
import { Pill } from '../icons/Pill';
import { Button } from '../ui/button';
import { useApp } from '@/contexts/app-provider';
import { Bookmark } from 'lucide-react';
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '../ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import MedicineAssistant from './MedicineAssistant';

interface MedicineInfoSheetProps {
  medicine: Medicine | null;
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
}

const AgeWarningIcon = ({ age }: { age: 'child' | 'adult' | 'elderly' }) => {
  switch (age) {
    case 'child': return <Baby className="w-5 h-5 text-blue-500" />;
    case 'adult': return <User className="w-5 h-5 text-green-500" />;
    case 'elderly': return <UserCog className="w-5 h-5 text-purple-500" />;
    default: return <User className="w-5 h-5" />;
  }
}

export default function MedicineInfoSheet({ medicine, isOpen, onOpenChange }: MedicineInfoSheetProps) {
  const { bookmarkedMedicines, addBookmark, removeBookmark } = useApp();
  const [isConsultDialogOpen, setConsultDialogOpen] = useState(false);
  
  if (!medicine) return null;
  
  const isBookmarked = bookmarkedMedicines.includes(medicine.id);

  return (
    <>
      <Sheet open={isOpen} onOpenChange={onOpenChange}>
        <SheetContent className="w-full sm:max-w-2xl flex flex-col">
          <SheetHeader>
            <div className="flex justify-between items-start">
              <div>
                <SheetTitle className="font-headline text-3xl">{medicine.name}</SheetTitle>
                <SheetDescription>{medicine.usage}</SheetDescription>
              </div>
              <Button variant="ghost" size="icon" onClick={() => isBookmarked ? removeBookmark(medicine.id) : addBookmark(medicine.id)}>
                <Bookmark className={`w-6 h-6 transition-colors ${isBookmarked ? 'text-yellow-500 fill-yellow-400' : 'text-muted-foreground'}`} />
              </Button>
            </div>
          </SheetHeader>
          
          <Tabs defaultValue="details" className="flex-1 flex flex-col min-h-0">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="ai-assistant" className="flex items-center gap-2"><Sparkles className="w-4 h-4"/>AI Assistant</TabsTrigger>
            </TabsList>
            
            <TabsContent value="details" className="flex-1 overflow-y-auto -mx-6 px-6">
              <div className="py-6 space-y-6">
                <div>
                  <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-primary" /> Dosage Timeline
                  </h4>
                  <div className="relative bg-muted/50 p-4 rounded-lg">
                      <div className="absolute left-6 right-6 top-1/2 -translate-y-1/2 h-0.5 bg-border"></div>
                      <div className="relative flex justify-around items-end text-center h-20">
                          <div className={`flex flex-col items-center gap-1.5 transition-opacity ${medicine.timetable.morning ? 'opacity-100' : 'opacity-30'}`}>
                              <Sunrise className="w-7 h-7"/>
                              <span className="text-sm font-medium">Morning</span>
                              {medicine.timetable.morning && <Pill className="w-5 h-5 text-primary" />}
                          </div>
                          <div className={`flex flex-col items-center gap-1.5 transition-opacity ${medicine.timetable.afternoon ? 'opacity-100' : 'opacity-30'}`}>
                              <Sun className="w-7 h-7"/>
                              <span className="text-sm font-medium">Afternoon</span>
                              {medicine.timetable.afternoon && <Pill className="w-5 h-5 text-primary" />}
                          </div>
                          <div className={`flex flex-col items-center gap-1.5 transition-opacity ${medicine.timetable.night ? 'opacity-100' : 'opacity-30'}`}>
                              <Sunset className="w-7 h-7"/>
                              <span className="text-sm font-medium">Night</span>
                              {medicine.timetable.night && <Pill className="w-5 h-5 text-primary" />}
                          </div>
                      </div>
                  </div>
                  <p className="text-sm text-muted-foreground mt-3 p-3 bg-secondary rounded-lg border">{medicine.dosage}</p>
                </div>

                <Separator />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-lg mb-2 flex items-center gap-2"><CheckCircle className="w-5 h-5 text-green-500" />Benefits</h4>
                    <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                      {medicine.benefits.map((benefit, i) => <li key={i}>{benefit}</li>)}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2 flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-amber-500" />Side Effects</h4>
                    <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                      {medicine.sideEffects.map((effect, i) => <li key={i}>{effect}</li>)}
                    </ul>
                  </div>
                </div>
                
                <Separator />

                <div>
                  <h4 className="font-semibold text-lg mb-3 flex items-center gap-2"><Ban className="w-5 h-5 text-rose-500" />Interaction Warnings</h4>
                  <div className="space-y-2">
                    {medicine.interactionWarnings.map((warning, i) => (
                      <div key={i} className="flex items-start gap-3 bg-rose-500/10 border-l-4 border-rose-500 text-rose-800 dark:text-rose-200 p-3 rounded-r-lg">
                        <Drama className="w-5 h-5 mt-0.5 flex-shrink-0" />
                        <p className="font-medium ">{warning}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                   <h4 className="font-semibold text-lg mb-3 flex items-center gap-2"><ShieldAlert className="w-5 h-5 text-destructive" />General & Age-Based Warnings</h4>
                   <div className="space-y-3">
                    {Object.entries(medicine.ageWarnings).map(([age, warnings]) => (
                      warnings.length > 0 && (
                        <div key={age}>
                          <h5 className="font-bold text-sm capitalize flex items-center gap-2 mb-1">
                            <AgeWarningIcon age={age as 'child'|'adult'|'elderly'} /> For {age}
                          </h5>
                          {warnings.map((warning, i) => (
                            <div key={i} className="text-sm text-muted-foreground ml-7 border-l-2 border-border pl-3 pb-1">{warning}</div>
                          ))}
                        </div>
                      )
                    ))}
                     {medicine.warnings.map((warning, i) => (
                      <div key={i} className="bg-destructive/10 border-l-4 border-destructive text-destructive-foreground p-3 rounded-r-lg">
                        <p className="font-medium text-red-800 dark:text-red-200">{warning}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="ai-assistant" className="flex-1 flex flex-col min-h-0 -mx-6 px-6 pt-2 pb-4">
                <MedicineAssistant medicine={medicine} />
            </TabsContent>
          </Tabs>

          <SheetFooter className="mt-auto gap-2 sm:flex-col sm:justify-end pt-4 border-t">
            <Button onClick={() => setConsultDialogOpen(true)} variant="default" className="w-full">
              <HeartPulse className="mr-2 h-4 w-4"/>
              Consult a Doctor Online
            </Button>
          </SheetFooter>
        </SheetContent>
      </Sheet>

      <Dialog open={isConsultDialogOpen} onOpenChange={setConsultDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Online Consultation</DialogTitle>
              <DialogDescription>
                This is a placeholder for a future doctor consultation feature.
              </DialogDescription>
            </DialogHeader>
            <div className="py-8 text-center text-muted-foreground">
              <p>Connecting you to a doctor...</p>
              <p className="text-sm">(This is a mock UI)</p>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button type="button">Close</Button>
              </DialogClose>
            </DialogFooter>
          </DialogContent>
        </Dialog>
    </>
  );
}
