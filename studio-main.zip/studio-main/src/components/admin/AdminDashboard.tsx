"use client";

import React, { useState } from 'react';
import type { Medicine, Pharmacy } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Plus, Upload, ShoppingCart, Settings } from 'lucide-react';
import { useAuth } from '@/contexts/auth-context';
import { Badge } from '@/components/ui/badge';
import PharmacyManagement from './PharmacyManagement';
import OrderManagement from './OrderManagement';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from '@/hooks/use-toast';


interface AdminDashboardProps {
  initialPharmacies: Pharmacy[];
  initialMedicines: Medicine[];
}

export default function AdminDashboard({ initialPharmacies, initialMedicines }: AdminDashboardProps) {
  const { user } = useAuth();
  const [isBulkUploadOpen, setBulkUploadOpen] = useState(false);
  const { toast } = useToast();

  const handleBulkUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      toast({
        title: "File Received",
        description: `Processing ${file.name}. This is a mock-up; no data will be changed.`,
      });
      setBulkUploadOpen(false);
    }
  };

  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-headline font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">Manage pharmacies, orders, and stock. Logged in as <Badge variant="outline">{user?.role}</Badge></p>
        </div>
        <div>
          <Button onClick={() => setBulkUploadOpen(true)} variant="outline" size="lg">
              <Upload className="mr-2 h-5 w-5" /> Bulk Upload
          </Button>
        </div>
      </div>

      <Tabs defaultValue="pharmacies" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="pharmacies" className="gap-2"><Settings />Pharmacy & Stock</TabsTrigger>
          <TabsTrigger value="orders" className="gap-2"><ShoppingCart />Order Management</TabsTrigger>
        </TabsList>
        <TabsContent value="pharmacies" className="mt-6">
          <PharmacyManagement initialPharmacies={initialPharmacies} initialMedicines={initialMedicines} />
        </TabsContent>
        <TabsContent value="orders" className="mt-6">
          {user?.role === 'Super Admin' ? (
            <OrderManagement />
          ) : (
             <Card className="text-center p-8">
                <CardHeader>
                    <CardTitle>Access Restricted</CardTitle>
                    <CardDescription>You must be a Super Admin to manage orders.</CardDescription>
                </CardHeader>
             </Card>
          )}
        </TabsContent>
      </Tabs>
      
       <Dialog open={isBulkUploadOpen} onOpenChange={setBulkUploadOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Bulk Stock Upload</DialogTitle>
            <DialogDescription>
              Upload a CSV file to update medicine stock for multiple pharmacies at once. The CSV should have columns: `pharmacy_id`, `medicine_id`, `stock`, `available`.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Input type="file" accept=".csv" onChange={handleBulkUpload} />
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="secondary">Cancel</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
