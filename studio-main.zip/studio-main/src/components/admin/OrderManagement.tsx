"use client";

import React from 'react';
import { useCollection } from '@/firebase/firestore/use-collection';
import { collection, doc } from 'firebase/firestore';
import { useFirestore, useMemoFirebase, useUser } from '@/firebase';
import type { Order } from '@/lib/types';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';
import { updateDocumentNonBlocking } from '@/firebase';
import { useAuth } from '@/contexts/auth-context';

function OrderRowSkeleton() {
    return (
        <TableRow>
            <TableCell><Skeleton className="h-5 w-24" /></TableCell>
            <TableCell><Skeleton className="h-5 w-32" /></TableCell>
            <TableCell><Skeleton className="h-5 w-40" /></TableCell>
            <TableCell className="text-right"><Skeleton className="h-5 w-20 ml-auto" /></TableCell>
            <TableCell><Skeleton className="h-5 w-28" /></TableCell>
            <TableCell><Skeleton className="h-9 w-32" /></TableCell>
        </TableRow>
    )
}

export default function OrderManagement() {
    const firestore = useFirestore();
    const { user } = useAuth();
    
    const ordersQuery = useMemoFirebase(() => {
        if (!firestore || !user || user.role !== 'Super Admin') return null;
        return collection(firestore, 'orders');
    }, [firestore, user]);

    const { data: orders, isLoading } = useCollection<Order>(ordersQuery);

    const handleStatusChange = (orderId: string, newStatus: Order['status']) => {
        if (!firestore || !orderId) return;
        const orderRef = doc(firestore, 'orders', orderId);
        updateDocumentNonBlocking(orderRef, { status: newStatus });
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Order Management</CardTitle>
                <CardDescription>View and manage all customer orders.</CardDescription>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Order Date</TableHead>
                            <TableHead>Customer</TableHead>
                            <TableHead>Contact</TableHead>
                            <TableHead className="text-right">Total</TableHead>
                            <TableHead>Payment</TableHead>
                            <TableHead>Status</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading && [...Array(5)].map((_, i) => <OrderRowSkeleton key={i} />)}
                        {orders && orders.map(order => (
                            <TableRow key={order.id}>
                                <TableCell>{format(new Date(order.orderDate), 'PPp')}</TableCell>
                                <TableCell className="font-medium">{order.customerName}</TableCell>
                                <TableCell>
                                    <div>{order.customerPhone}</div>
                                    <div className="text-xs text-muted-foreground">{order.customerAddress}</div>
                                </TableCell>
                                <TableCell className="text-right font-mono">${order.totalAmount.toFixed(2)}</TableCell>
                                <TableCell>
                                    <Badge variant="outline">{order.paymentMethod}</Badge>
                                </TableCell>
                                <TableCell>
                                    <Select value={order.status} onValueChange={(value) => handleStatusChange(order.id, value as Order['status'])}>
                                        <SelectTrigger className="w-32 h-9">
                                            <SelectValue placeholder="Status" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Pending">Pending</SelectItem>
                                            <SelectItem value="Processing">Processing</SelectItem>
                                            <SelectItem value="Shipped">Shipped</SelectItem>
                                            <SelectItem value="Delivered">Delivered</SelectItem>
                                            <SelectItem value="Cancelled">Cancelled</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {!isLoading && orders?.length === 0 && (
                    <div className="text-center p-8 text-muted-foreground">
                        No orders have been placed yet.
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
