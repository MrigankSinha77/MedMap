"use client";

import React, { useState, useMemo } from 'react';
import type { Medicine, Pharmacy, PharmacyMedicine, ActivityLog } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Plus, Edit, Trash2, Pill, Store, Building, MoreVertical, History, TrendingUp, Thermometer, BarChart, Eye } from 'lucide-react';
import { Switch } from '../ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useAuth } from '@/contexts/auth-context';
import { useApp } from '@/contexts/app-provider';
import { format } from 'date-fns';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';

interface PharmacyManagementProps {
  initialPharmacies: Pharmacy[];
  initialMedicines: Medicine[];
}

const ActivityLogItem: React.FC<{ log: ActivityLog }> = ({ log }) => (
    <div className="flex items-start gap-4 p-3 hover:bg-secondary/50 rounded-lg">
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-lg">
            {log.user.name.charAt(0)}
        </div>
        <div>
            <p className="font-medium">{log.action}</p>
            <p className="text-sm text-muted-foreground">
                by {log.user.name} ({log.user.role}) at {format(log.timestamp, 'PPpp')}
            </p>
        </div>
    </div>
);


export default function PharmacyManagement({ initialPharmacies, initialMedicines }: PharmacyManagementProps) {
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>(initialPharmacies);
  const [medicines, setMedicines] = useState<Medicine[]>(initialMedicines);
  const [isFormOpen, setFormOpen] = useState(false);
  const [editingPharmacy, setEditingPharmacy] = useState<Pharmacy | null>(null);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const { toast } = useToast();
  const { user } = useAuth();
  const { searchCounts } = useApp();

  const canEdit = user?.role === 'Super Admin' || user?.role === 'Pharmacy Admin';
  const canDelete = user?.role === 'Super Admin';

  const addActivityLog = (action: string) => {
    if (!user) return;
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      user: { name: user.name, role: user.role },
      action,
      timestamp: new Date(),
    };
    setActivityLogs(prev => [newLog, ...prev].slice(0, 50));
  };
  
  const handleAddPharmacy = () => {
    setEditingPharmacy(null);
    setFormOpen(true);
  };
  
  const handleEditPharmacy = (pharmacy: Pharmacy) => {
    setEditingPharmacy(pharmacy);
    setFormOpen(true);
  };

  const handleDeletePharmacy = (pharmacyId: string) => {
    const pharmacyName = pharmacies.find(p => p.id === pharmacyId)?.name;
    setPharmacies(pharmacies.filter(p => p.id !== pharmacyId));
    toast({ title: "Success", description: `Pharmacy "${pharmacyName}" deleted.` });
    addActivityLog(`Deleted pharmacy: ${pharmacyName}`);
  };
  
  const handleSavePharmacy = (formData: Omit<Pharmacy, 'id' | 'imageId'> & {medicines: PharmacyMedicine[]}) => {
    if (editingPharmacy) {
      setPharmacies(pharmacies.map(p => p.id === editingPharmacy.id ? { ...editingPharmacy, ...formData } : p));
      toast({ title: "Success", description: "Pharmacy updated successfully." });
      addActivityLog(`Updated pharmacy: ${formData.name}`);
    } else {
      const newPharmacy: Pharmacy = {
        id: `pharma${pharmacies.length + 2}`,
        imageId: `pharmacy-${(pharmacies.length % 4) + 1}`,
        isAlwaysOpen: false, // Default value
        ...formData
      };
      setPharmacies([...pharmacies, newPharmacy]);
      toast({ title: "Success", description: "Pharmacy added successfully." });
      addActivityLog(`Added new pharmacy: ${formData.name}`);
    }
    setFormOpen(false);
  };

  const trendingMedicines = useMemo(() => {
    return Object.entries(searchCounts)
        .map(([medicineId, count]) => {
            const medicine = initialMedicines.find(m => m.id === medicineId);
            return {
                id: medicineId,
                name: medicine?.name || 'Unknown',
                count
            };
        })
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);
  }, [searchCounts, initialMedicines]);


  return (
    <div>
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Pharmacy Management</h2>
            {canEdit && (
                <Button onClick={handleAddPharmacy}>
                    <Plus className="mr-2 h-5 w-5" /> Add Pharmacy
                </Button>
            )}
        </div>
       {user?.role === 'Super Admin' && (
         <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><BarChart className="text-primary"/>Analytics</CardTitle>
                    <CardDescription>Insights into medicine demand and trends.</CardDescription>
                </CardHeader>
                <CardContent>
                    <h4 className="font-semibold mb-3 flex items-center gap-2"><TrendingUp className="w-5 h-5"/>Trending Medicines (by searches)</h4>
                     {trendingMedicines.length > 0 ? (
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Medicine</TableHead>
                                    <TableHead className="text-right">Search Count</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {trendingMedicines.map(med => (
                                    <TableRow key={med.id}>
                                        <TableCell className="font-medium">{med.name}</TableCell>
                                        <TableCell className="text-right">{med.count}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                     ) : (
                        <p className="text-sm text-muted-foreground text-center py-4">No search data yet.</p>
                     )}
                </CardContent>
            </Card>
             <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><History className="text-primary"/>Activity Logs</CardTitle>
                    <CardDescription>Recent changes made by administrators.</CardDescription>
                </CardHeader>
                <CardContent className="max-h-80 overflow-y-auto">
                    <div className="space-y-2">
                        {activityLogs.length > 0 ? activityLogs.map(log => <ActivityLogItem key={log.id} log={log} />)
                         : (
                            <p className="text-sm text-muted-foreground text-center py-4">No activity recorded yet.</p>
                         )}
                    </div>
                </CardContent>
            </Card>
        </div>
      )}


      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {pharmacies.map((pharmacy, index) => (
          <Card 
            key={pharmacy.id} 
            className="flex flex-col animate-fade-in-up"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <CardHeader className="flex-shrink-0">
              <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="font-headline text-2xl">{pharmacy.name}</CardTitle>
                    <CardDescription className="flex items-center gap-2 pt-1">
                      <Building className="w-4 h-4"/>{pharmacy.city}
                      {pharmacy.isAlwaysOpen && <Badge variant="secondary" className="ml-2">24/7</Badge>}
                    </CardDescription>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0">
                            <MoreVertical className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        {canEdit && (
                          <DropdownMenuItem onClick={() => handleEditPharmacy(pharmacy)}>
                              <Edit className="mr-2 h-4 w-4" /> Edit
                          </DropdownMenuItem>
                        )}
                         {!canEdit && (
                            <DropdownMenuItem disabled>
                                <Eye className="mr-2 h-4 w-4" /> View Only
                            </DropdownMenuItem>
                        )}
                        {canDelete && (
                          <AlertDialog>
                              <AlertDialogTrigger asChild>
                                  <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                                      <Trash2 className="mr-2 h-4 w-4" /> 
                                      <span>Delete</span>
                                  </DropdownMenuItem>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                  <AlertDialogHeader>
                                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                      This action cannot be undone. This will permanently delete the pharmacy and its stock data.
                                  </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDeletePharmacy(pharmacy.id)} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
                                  </AlertDialogFooter>
                              </AlertDialogContent>
                          </AlertDialog>
                        )}
                    </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <h4 className="font-semibold mb-3 flex items-center gap-2"><Pill className="w-5 h-5 text-primary"/>Stock Details</h4>
              <div className="space-y-3 max-h-48 overflow-y-auto pr-2">
                {pharmacy.medicines.map(pm => {
                  const medicine = medicines.find(m => m.id === pm.medicineId);
                  const demand = searchCounts[pm.medicineId] || 0;
                  const isHighDemand = demand > 5; // Arbitrary threshold for high demand
                  const isLowStock = pm.stock < 20; // Arbitrary threshold for low stock

                  return (
                    <div key={pm.medicineId} className="flex justify-between items-center bg-secondary/70 p-3 rounded-lg">
                      <div>
                        <p className="font-medium">{medicine?.name}</p>
                        <p className="text-sm text-muted-foreground">Quantity: {pm.stock}</p>
                         {(isHighDemand || isLowStock) && (
                           <div className="flex gap-2 mt-1.5">
                            {isHighDemand && <Badge variant="outline" className="text-amber-600 border-amber-500"><TrendingUp className="w-3 h-3 mr-1"/>High Demand</Badge>}
                            {isLowStock && <Badge variant="destructive"><Thermometer className="w-3 h-3 mr-1"/>Low Stock</Badge>}
                           </div>
                         )}
                      </div>
                      <Badge variant={pm.available ? 'default' : 'destructive'} className={pm.available ? 'bg-green-600' : ''}>
                        {pm.available ? 'Available' : 'Unavailable'}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <PharmacyForm 
        isOpen={isFormOpen} 
        onOpenChange={setFormOpen} 
        pharmacy={editingPharmacy} 
        onSave={handleSavePharmacy}
        allMedicines={medicines}
      />
    </div>
  );
}

interface PharmacyFormProps {
    isOpen: boolean;
    onOpenChange: (isOpen: boolean) => void;
    pharmacy: Pharmacy | null;
    onSave: (formData: Omit<Pharmacy, 'id' | 'imageId'> & {medicines: PharmacyMedicine[]}) => void;
    allMedicines: Medicine[];
}

function PharmacyForm({isOpen, onOpenChange, pharmacy, onSave, allMedicines}: PharmacyFormProps) {
    const [name, setName] = useState('');
    const [city, setCity] = useState('');
    const [isAlwaysOpen, setAlwaysOpen] = useState(false);
    const [managedMedicines, setManagedMedicines] = useState<PharmacyMedicine[]>([]);

    React.useEffect(() => {
        if (pharmacy) {
            setName(pharmacy.name);
            setCity(pharmacy.city);
            setAlwaysOpen(pharmacy.isAlwaysOpen);
            setManagedMedicines(pharmacy.medicines);
        } else {
            setName('');
            setCity('');
            setAlwaysOpen(false);
            setManagedMedicines([]);
        }
    }, [pharmacy, isOpen]);

    const handleAddMedicine = (medicineId: string) => {
        if (medicineId && !managedMedicines.some(m => m.medicineId === medicineId)) {
            setManagedMedicines([...managedMedicines, { medicineId, stock: 0, available: false }]);
        }
    };
    
    const handleUpdateMedicine = (medicineId: string, field: keyof PharmacyMedicine, value: string | number | boolean) => {
        setManagedMedicines(managedMedicines.map(m => m.medicineId === medicineId ? {...m, [field]: value} : m));
    }

    const handleRemoveMedicine = (medicineId: string) => {
        setManagedMedicines(managedMedicines.filter(m => m.medicineId !== medicineId));
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ name, city, isAlwaysOpen, medicines: managedMedicines });
    };

    const availableMedsToAdd = allMedicines.filter(med => !managedMedicines.some(pm => pm.medicineId === med.id));
    
    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
                <DialogHeader>
                    <DialogTitle className="font-headline text-2xl">{pharmacy ? 'Edit Pharmacy' : 'Add New Pharmacy'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="overflow-y-auto px-1 -mx-1 space-y-6 flex-grow">
                    <div className="px-1 space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="name">Pharmacy Name</Label>
                            <Input id="name" value={name} onChange={e => setName(e.target.value)} required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="city">City</Label>
                            <Input id="city" value={city} onChange={e => setCity(e.target.value)} required />
                        </div>
                        <div className="flex items-center space-x-2 pt-2">
                            <Switch id="always-open" checked={isAlwaysOpen} onCheckedChange={setAlwaysOpen} />
                            <Label htmlFor="always-open">Open 24/7</Label>
                        </div>
                    </div>

                    <div className="space-y-4 pt-4 border-t">
                       <h3 className="font-semibold text-lg px-1">Manage Medicines</h3>
                       <div className="flex gap-2 px-1">
                        <Select onValueChange={handleAddMedicine}>
                            <SelectTrigger>
                                <SelectValue placeholder="Add a medicine to manage..." />
                            </SelectTrigger>
                            <SelectContent>
                                {availableMedsToAdd.length > 0 ? (
                                    availableMedsToAdd.map(med => <SelectItem key={med.id} value={med.id}>{med.name}</SelectItem>)
                                 ) : (
                                    <div className="p-2 text-sm text-muted-foreground text-center">All medicines added.</div>
                                 )}
                            </SelectContent>
                        </Select>
                       </div>
                       
                        <div className="space-y-3 max-h-64 overflow-y-auto p-1">
                            {managedMedicines.map(pm => {
                                const medicine = allMedicines.find(m => m.id === pm.medicineId);
                                return (
                                    <div key={pm.medicineId} className="grid grid-cols-4 gap-x-4 gap-y-2 items-center p-3 rounded-lg bg-secondary/70">
                                        <p className="font-medium col-span-4 sm:col-span-1">{medicine?.name}</p>
                                        <div className="col-span-2 sm:col-span-1">
                                            <Label htmlFor={`stock-${pm.medicineId}`} className="text-xs text-muted-foreground">Stock Qty</Label>
                                            <Input 
                                                id={`stock-${pm.medicineId}`} 
                                                type="number" 
                                                value={pm.stock}
                                                onChange={e => handleUpdateMedicine(pm.medicineId, 'stock', Number(e.target.value))}
                                                className="h-9"
                                            />
                                        </div>
                                        <div className="flex items-center space-x-2 justify-center col-span-2 sm:col-span-1">
                                            <Label htmlFor={`available-${pm.medicineId}`} className="text-xs text-muted-foreground">Available</Label>
                                            <Switch
                                                id={`available-${pm.medicineId}`}
                                                checked={pm.available}
                                                onCheckedChange={checked => handleUpdateMedicine(pm.medicineId, 'available', checked)}
                                            />
                                        </div>
                                        <div className="flex justify-end col-span-4 sm:col-span-1">
                                            <Button type="button" variant="ghost" size="icon" onClick={() => handleRemoveMedicine(pm.medicineId)} className="text-destructive hover:text-destructive hover:bg-destructive/10 rounded-full h-8 w-8">
                                                <Trash2 className="h-4 w-4"/>
                                            </Button>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                </form>
                <DialogFooter className="flex-shrink-0">
                    <DialogClose asChild>
                        <Button type="button" variant="outline">Cancel</Button>
                    </DialogClose>
                    <Button type="submit" onClick={handleSubmit}>Save Changes</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
