# **App Name**: PharmaFind

## Core Features:

- Medicine Search: Allows users to search for medicines by name, displaying instant results.
- Medicine Information Portal: Provides detailed information about medicines, including usage, dosage, benefits, side effects, and warnings. Displays medicine timetable (morning/afternoon/night), highlights warnings in red, and adds a 'Consult doctor' note. Displays info in a modal or side panel. Ensures info updates dynamically when user searches.
- Pharmacy Listing: Displays a list of pharmacies with their name, city, available medicines, and stock status.
- Admin Dashboard: Restricted access admin portal for managing pharmacies and medicines.
- Pharmacy Management: Allows admin to add new pharmacies, edit pharmacy details, and add/remove medicines.
- Medicine Stock Management: Allows admin to update medicine stock quantity and mark availability status.
- Access Control: Ensure admin portal access is granted only if ID matches: 25070122115. Require Firebase Authentication. Admin access only if ID = 25070122115. Block admin routes for non-admin users. Show unauthorized access page if ID mismatch.

## Style Guidelines:

- Primary color: Soft blue (#A0C4FF) to create a calming and trustworthy atmosphere, evoking the healthcare theme.
- Background color: Light, desaturated blue (#EBF0FF), providing a clean and modern backdrop.
- Accent color: Light violet (#BDB2FF), used sparingly for interactive elements and highlights to draw attention.
- Body and headline font: 'PT Sans', a humanist sans-serif which lends a modern yet warm and accessible feel to the app.
- Use clear, modern icons related to healthcare and medicine. Ensure they are easily recognizable and consistent throughout the app.
- Implement a mobile-first responsive layout with rounded cards and smooth transitions to enhance user experience.
- Use subtle animations for loading states and transitions to provide a smooth user experience.